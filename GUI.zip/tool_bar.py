"""
Only shown for the player that is drawing, used to store
all drawing buttons.
"""
